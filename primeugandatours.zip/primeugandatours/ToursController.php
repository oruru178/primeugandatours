<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ToursController extends Controller
{
    public function index()
    {
        $tours = [
            [
                'title' => 'Mountain Gorilla Trek',
                'description' => 'Experience the thrill of tracking mountain gorillas in the dense forests of Bwindi Impenetrable National Park.',
                'image' => 'https://source.unsplash.com/random/800x600?mountain,gorilla',
            ],
            [
                'title' => 'Nile Safari',
                'description' => 'Embark on a thrilling boat safari along the Nile River to spot hippos, crocodiles, and other wildlife.',
                'image' => 'https://source.unsplash.com/random/800x600?nile,safari',
            ],
            [
                'title' => 'Chimpanzee Trek',
                'description' => 'Discover the fascinating world of chimpanzees in Kibale Forest National Park.',
                'image' => 'https://source.unsplash.com/random/800x600?chimpanzee,trek',
            ],
        ];

        return view('tours.index', compact('tours'));
    }

    public function show($id)
    {
        $tours = [
            [
                'id' => 1,
                'title' => 'Mountain Gorilla Trek',
                'description' => 'Experience the thrill of tracking mountain gorillas in the dense forests of Bwindi Impenetrable National Park.',
                'image' => 'https://source.unsplash.com/random/800x600?mountain,gorilla',
            ],
            [
                'id' => 2,
                'title' => 'Nile Safari',
                'description' => 'Embark on a thrilling boat safari along the Nile River to spot hippos, crocodiles, and other wildlife.',
                'image' => 'https://source.unsplash.com/random/800x600?nile,safari',
            ],
            [
                'id' => 3,
                'title' => 'Chimpanzee Trek',
                'description' => 'Discover the fascinating world of chimpanzees in Kibale Forest National Park.',
                'image' => 'https://source.unsplash.com/random/800x600?chimpanzee,trek',
            ],
        ];

        $tour = $tours[$id - 1];

        return view('tours.show', compact('tour'));
    }
}