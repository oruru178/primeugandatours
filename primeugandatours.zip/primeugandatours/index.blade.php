
@section('content')
    <div class="container">
        <h1>Prime Uganda Tours</h1>

        <div class="row">
            @foreach($tours as $tour)
                <div class="col-md-4">
                    <div class="card mb-4 shadow-sm">
                        <img class="card-img-top" src="{{ $tour['image'] }}" alt="{{ $tour['title'] }}">
                        <div class="card-body">
                            <h5 class="card-title">{{ $tour['title'] }}</h5>
                            <p class="card-text">{{ $tour['description'] }}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="/tours/{{ $loop->index + 1 }}" class="btn btn-sm btn-outline-secondary">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection